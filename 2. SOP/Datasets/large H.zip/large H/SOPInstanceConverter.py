import random, ReadData
import Classes
from matplotlib import pyplot as plt
import os
from VisualizeSolution import visualizeTSP, visualizeSOP
from ReadData import writeSOPinTxt
import openpyxl


def readDatasetT(filename):
   print(filename[0:-5])

   wb_obj = openpyxl.load_workbook('GLKH_optimal.xlsx')
   sheet_obj = wb_obj.active
   row = 1
   for i in range(2,46):
      value = sheet_obj.cell(i, 2).value
      #print(value)
      if value == filename[0:-5]:
         row = i

   T = sheet_obj.cell(row, 3).value
   return T


path = os.getcwd()
path = "large"
for filename in os.listdir(path):
   print(filename)
   if filename.endswith('.gtsp'):#  and filename.startswith("10C1k.0"): # 350vm1748 2000C10k.0
      with open(os.path.join(path, filename), 'r') as f:

         contents = f.readlines()
         print(contents)

         m = ReadData.importGTSPModel(filename)

         if True:
            m2 = ReadData.importGTSPModel(filename)

            #visualizeSOP(m)

            sop = ReadData.generateSOPModel(filename, m, "")
            sopRND = ReadData.generateSOPModel(filename, m2, "RND")
            visualizeSOP(sop)
            visualizeSOP(sopRND)


            for category in ["","RND"]:
               for profit in ["p1", "p2"]:
                  for t_percentage in ["T40", "T60", "T80", "T100"]:

                     T = readDatasetT(filename)

                     if category == "":
                        sop = ReadData.CalculateRest(sop, T, category, profit, t_percentage)
                     elif category == "RND":
                        sop = ReadData.CalculateRest(sopRND, T, category, profit, t_percentage)


                     #sop = ReadData.generateSOPModel(filename, m, T, category, profit, t_percentage)

                     #visualizeSOP(m)

                     writeSOPinTxt(sop, contents)
